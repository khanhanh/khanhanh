package baithi;

public class Main {
    public static void main(String[] args) {
//        Hotel 1-10
        Hotel hotel = new Hotel();
        hotel.EnterHotel();


        Hotel hotel1 = new Hotel();
        hotel1.EnterHotel();

        Hotel hotel2 = new Hotel();
        hotel2.EnterHotel();


        Hotel hotel3 = new Hotel();
        hotel3.EnterHotel();


        Hotel hotel4 = new Hotel();
        hotel4.EnterHotel();


        Hotel hotel5 = new Hotel();
        hotel5.EnterHotel();


        Hotel hotel6 = new Hotel();
        hotel6.EnterHotel();


        Hotel hotel7 = new Hotel();
        hotel7.EnterHotel();


        Hotel hotel8 = new Hotel();
        hotel8.EnterHotel();


        Hotel hotel9 = new Hotel();
        hotel9.EnterHotel();

        hotel.InforHotel();
        hotel1.InforHotel();
        hotel2.InforHotel();
        hotel3.InforHotel();
        hotel4.InforHotel();
        hotel5.InforHotel();
        hotel6.InforHotel();
        hotel7.InforHotel();
        hotel8.InforHotel();
        hotel9.InforHotel();


    }
}
